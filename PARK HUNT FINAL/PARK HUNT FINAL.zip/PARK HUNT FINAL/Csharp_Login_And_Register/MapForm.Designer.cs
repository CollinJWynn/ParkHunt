﻿namespace Csharp_Login_And_Register
{
    partial class MapForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MapForm));
            this.LotAAvailable = new System.Windows.Forms.Label();
            this.lotBAvailable = new System.Windows.Forms.Label();
            this.lotCAvailable = new System.Windows.Forms.Label();
            this.lotDAvailable = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LotAAvailable
            // 
            this.LotAAvailable.AutoSize = true;
            this.LotAAvailable.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LotAAvailable.Location = new System.Drawing.Point(837, 48);
            this.LotAAvailable.Name = "LotAAvailable";
            this.LotAAvailable.Size = new System.Drawing.Size(153, 54);
            this.LotAAvailable.TabIndex = 0;
            this.LotAAvailable.Text = "label1";
            this.LotAAvailable.Click += new System.EventHandler(this.label1_Click);
            // 
            // lotBAvailable
            // 
            this.lotBAvailable.AutoSize = true;
            this.lotBAvailable.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lotBAvailable.Location = new System.Drawing.Point(1136, 104);
            this.lotBAvailable.Name = "lotBAvailable";
            this.lotBAvailable.Size = new System.Drawing.Size(153, 54);
            this.lotBAvailable.TabIndex = 1;
            this.lotBAvailable.Text = "label2";
            // 
            // lotCAvailable
            // 
            this.lotCAvailable.AutoSize = true;
            this.lotCAvailable.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lotCAvailable.Location = new System.Drawing.Point(744, 442);
            this.lotCAvailable.Name = "lotCAvailable";
            this.lotCAvailable.Size = new System.Drawing.Size(153, 54);
            this.lotCAvailable.TabIndex = 2;
            this.lotCAvailable.Text = "label3";
            // 
            // lotDAvailable
            // 
            this.lotDAvailable.AutoSize = true;
            this.lotDAvailable.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lotDAvailable.Location = new System.Drawing.Point(1180, 217);
            this.lotDAvailable.Name = "lotDAvailable";
            this.lotDAvailable.Size = new System.Drawing.Size(153, 54);
            this.lotDAvailable.TabIndex = 3;
            this.lotDAvailable.Text = "label4";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(752, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(238, 32);
            this.label1.TabIndex = 4;
            this.label1.Text = "YOU ARE HERE";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(26, 27);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(161, 75);
            this.button1.TabIndex = 5;
            this.button1.Text = "BACK";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(789, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 54);
            this.label2.TabIndex = 6;
            this.label2.Text = "A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1071, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 54);
            this.label3.TabIndex = 7;
            this.label3.Text = "B";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(684, 442);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 54);
            this.label4.TabIndex = 8;
            this.label4.Text = "C";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1120, 217);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 54);
            this.label5.TabIndex = 9;
            this.label5.Text = "D";
            // 
            // MapForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1600, 872);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lotDAvailable);
            this.Controls.Add(this.lotCAvailable);
            this.Controls.Add(this.lotBAvailable);
            this.Controls.Add(this.LotAAvailable);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "MapForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MapForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LotAAvailable;
        private System.Windows.Forms.Label lotBAvailable;
        private System.Windows.Forms.Label lotCAvailable;
        private System.Windows.Forms.Label lotDAvailable;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}